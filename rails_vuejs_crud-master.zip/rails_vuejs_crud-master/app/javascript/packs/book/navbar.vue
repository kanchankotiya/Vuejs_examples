<template id="book-navbar">
  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Rails 5.1 - Vue.js 2 - Webpack - CRUD</a>
      </div>
    </div>
  </nav>
</template>
