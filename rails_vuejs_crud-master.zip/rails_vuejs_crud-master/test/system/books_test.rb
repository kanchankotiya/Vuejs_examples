require "application_system_test_case"

class BooksTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit books_url
  #
  #   assert_selector "h1", text: "Book"
  # end
end
