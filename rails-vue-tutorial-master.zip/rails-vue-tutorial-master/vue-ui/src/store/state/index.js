import * as states from "@/store/state/types";

// Initilize the state of the app.
export default {
  [states.EVENTS]: []
};
