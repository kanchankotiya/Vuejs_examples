export const GET_EVENTS = "GET_EVENTS";
export const SAVE_EVENT = "SAVE_EVENT";
export const DELETE_EVENT = "DELETE_EVENT";
