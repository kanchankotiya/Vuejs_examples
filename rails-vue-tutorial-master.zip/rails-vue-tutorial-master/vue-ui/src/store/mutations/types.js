export const SET_EVENTS = "SET_EVENTS";
export const SET_EVENT = "SET_EVENT";
export const DELETE_EVENT = "DELETE_EVENT";
